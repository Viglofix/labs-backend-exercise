package com.labs1.backend_labs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendLabsApplicationTests {

	@Test
	void contextLoads() {
	}

}
