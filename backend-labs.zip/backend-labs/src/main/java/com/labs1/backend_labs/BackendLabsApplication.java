package com.labs1.backend_labs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendLabsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendLabsApplication.class, args);
	}

}
